package com.zensar.sercurity.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HomeController {
	
	// http://localhost:8080/spring-sercurity-demo/home
	@RequestMapping("/home")
	public String  home() {
		return "home";
	}

}
