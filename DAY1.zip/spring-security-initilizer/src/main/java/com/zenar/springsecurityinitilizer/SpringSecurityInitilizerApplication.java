package com.zenar.springsecurityinitilizer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringSecurityInitilizerApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringSecurityInitilizerApplication.class, args);
	}

}
